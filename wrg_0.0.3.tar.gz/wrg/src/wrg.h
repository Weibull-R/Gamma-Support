#ifndef _wrg_H
#define _wrg_H


#include <RcppArmadillo.h>

// abremDebias code
RcppExport SEXP MLEloglike(SEXP arg1, SEXP arg3, SEXP arg4, SEXP arg5, SEXP arg6);



#endif
